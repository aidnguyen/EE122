import requests


def lambda_handler(event, context):

    url = "FILL THIS"
    response = requests.session().post(url, data=event, timeout=10)